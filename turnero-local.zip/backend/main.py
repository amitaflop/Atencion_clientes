from collections import deque
from datetime import datetime, timezone
from itertools import count
import asyncio

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

app = FastAPI(title="Turnero de atención")
app.add_middleware(CORSMiddleware, allow_origins=["http://localhost:4200"], allow_methods=["*"], allow_headers=["*"])
waiting = deque()
counter = count(1)
lock = asyncio.Lock()
clients: set[WebSocket] = set()
desks = {n: {"number": n, "ticket": None, "since": None} for n in range(1, 5)}

def snapshot():
    return {"waiting": list(waiting), "desks": list(desks.values()), "nextNumber": next_number}

next_number = 1

async def broadcast():
    payload = snapshot()
    gone = []
    for ws in clients:
        try:
            await ws.send_json(payload)
        except Exception:
            gone.append(ws)
    for ws in gone:
        clients.discard(ws)

@app.get("/api/state")
async def state():
    return snapshot()

@app.post("/api/tickets")
async def create_ticket():
    global next_number
    async with lock:
        ticket = {"number": next_number, "createdAt": datetime.now(timezone.utc).isoformat()}
        next_number += 1
        waiting.append(ticket)
        await broadcast()
        return {"ticket": ticket, **snapshot()}

@app.post("/api/call-next")
async def call_next():
    if not waiting:
        raise HTTPException(409, "No hay clientes en espera")
    free = [d for d in desks.values() if d["ticket"] is None]
    if not free:
        raise HTTPException(409, "Todas las mesas están ocupadas")
    async with lock:
        desk = min(free, key=lambda d: d["since"] or "")
        ticket = waiting.popleft()
        desk["ticket"] = ticket
        desk["since"] = datetime.now(timezone.utc).isoformat()
        await broadcast()
        return snapshot()

@app.post("/api/desks/{number}/finish")
async def finish(number: int):
    if number not in desks:
        raise HTTPException(404, "Mesa no encontrada")
    async with lock:
        desks[number]["ticket"] = None
        desks[number]["since"] = datetime.now(timezone.utc).isoformat()
        await broadcast()
        return snapshot()

@app.websocket("/ws")
async def websocket(ws: WebSocket):
    await ws.accept(); clients.add(ws); await ws.send_json(snapshot())
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        clients.discard(ws)
