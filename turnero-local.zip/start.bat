@echo off
cd /d "%~dp0"
start "Turnero API" cmd /k "cd /d "%~dp0backend" && call start-backend.bat"
timeout /t 3 /nobreak >nul
start "Turnero web" cmd /k "cd /d "%~dp0frontend" && call start-frontend.bat"
timeout /t 12 /nobreak >nul
start http://localhost:4200
