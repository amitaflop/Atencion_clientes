@echo off
setlocal
start "Turnero API" /D "%~dp0backend" cmd /k "call start-backend.bat"
start "Turnero web" /D "%~dp0frontend" cmd /k "if not exist node_modules npm install && npm start"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$limit=(Get-Date).AddMinutes(5); while ((Get-Date) -lt $limit) { if (Test-NetConnection -ComputerName 127.0.0.1 -Port 4200 -InformationLevel Quiet) { Start-Process 'http://localhost:4200'; exit 0 }; Start-Sleep -Seconds 2 }"
