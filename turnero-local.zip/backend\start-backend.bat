@echo off
setlocal
cd /d "%~dp0"
where python3.12 >nul 2>nul
if not errorlevel 1 (
  set "PYTHON=python3.12"
) else (
  set "PYTHON=python"
)
if not exist ".venv\Scripts\python.exe" (
  %PYTHON% -m venv .venv
  if errorlevel 1 exit /b 1
)
if not exist ".venv\Scripts\uvicorn.exe" (
  .venv\Scripts\python.exe -m pip install -r requirements.txt
  if errorlevel 1 exit /b 1
)
.venv\Scripts\python.exe -m uvicorn main:app --host 127.0.0.1 --port 8000
